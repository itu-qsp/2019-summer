# 7.py
