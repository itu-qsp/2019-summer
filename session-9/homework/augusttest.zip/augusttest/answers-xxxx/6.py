# 6.py
