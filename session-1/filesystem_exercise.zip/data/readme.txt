This is just a directory containing example data.

The images of Snoopy and the beavers come from the Caltech 101 dataset, see http://www.vision.caltech.edu/Image_Datasets/Caltech101/

The PNG images in the images folder come from https://www.pexels.com and were converted to PNG from the original JPG files

The books in the books and misc directory come from Project Gutenberg, see https://www.gutenberg.org/

Darwin's "Origin of Species" is from http://darwin-online.org.uk/converted/pdf/1861_OriginNY_F382.pdf